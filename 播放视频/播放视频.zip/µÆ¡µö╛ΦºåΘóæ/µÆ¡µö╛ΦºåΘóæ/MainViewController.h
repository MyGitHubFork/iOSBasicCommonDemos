//
//  MainViewController.h
//  播放视频
//
//  Created by aiteyuan on 15/1/7.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController

@end
